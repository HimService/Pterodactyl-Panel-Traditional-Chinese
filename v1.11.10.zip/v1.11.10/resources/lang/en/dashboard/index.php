<?php

return [
    'search' => '搜尋伺服器...',
    'no_matches' => '找不到符合提供搜尋條件的伺服器。',
    'cpu_title' => 'CPU',
    'memory_title' => '記憶體',
];
