<?php

return [
    'exceptions' => [
        'user_has_servers' => '無法刪除帳戶中擁有伺服器的使用者。請先刪除其伺服器再繼續。',
    ],
    'notices' => [
        'account_created' => '已成功建立帳戶。',
        'account_updated' => '已成功更新帳戶。',
    ],
];
